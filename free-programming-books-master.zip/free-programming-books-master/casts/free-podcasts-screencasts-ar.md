### Index

* [Miscellaneous](#miscellaneous)


### Miscellaneous

* [null++: بالعربي](https://nullplus.plus) - Mohamed Luay & Ahmad Alfy (podcast)
* [The Egyptian Guy](https://anchor.fm/refaie) - Mohamed Refaie (podcast)
