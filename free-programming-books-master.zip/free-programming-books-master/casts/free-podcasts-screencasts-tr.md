### Index

* [Dil Bağımsız](#dil-bağımsız)
* [JavaScript](#javascript)


### Dil Bağımsız

* [codefiction](https://codefiction.tech) (podcast)
* [devPod](https://devpod.org) (screencast)
* [kodpod](https://kodpod.live) (podcast)


### JavaScript

* [null podcast](https://soundcloud.com/nullpodcast) (podcast)
