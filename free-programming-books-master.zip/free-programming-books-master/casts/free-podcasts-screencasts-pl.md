### Index

* [Niezależne od języka programowania](#niezale%C5%BCne-od-j%C4%99zyka-programowania)


### Niezależne od języka programowania

* [DevTalk](https://devstyle.pl/category/podcast)
