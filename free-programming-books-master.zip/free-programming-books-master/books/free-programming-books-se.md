### Index

* [C](#c)
* [C++](#cpp)
* [PHP](#php)


### C

* [C-programmering](https://sv.wikibooks.org/wiki/C-programmering) - Wikibooks


<h3 id="cpp">C++</h3>

* [Programmera spel i C++ för nybörjare](https://sv.wikibooks.org/wiki/Programmera_spel_i_C%2B%2B_f%C3%B6r_nyb%C3%B6rjare) - Wikibooks


### MATLAB

* [Introduktion till MATLAB](https://www.liber.se/plus/E470523401.pdf) (PDF)


### PHP

* [Programmera i PHP](https://sv.wikibooks.org/wiki/Programmera_i_PHP) - Wikibooks
