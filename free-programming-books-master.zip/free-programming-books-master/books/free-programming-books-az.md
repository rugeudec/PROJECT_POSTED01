### Index

* [C](#c)
* [CSS](#css)
* [HTML](#html)
* [JavaScript](#javascript)
* [Linux](#Linux)
* [PHP](#php)


### C

* [C Proqramlaşdırma Dili](http://ilkaddimlar.com/ders/c-proqramlasdirma-dili)


### CSS

* [CSS](http://ilkaddimlar.com/ders/css)


### HTML

* [HTML](http://ilkaddimlar.com/ders/html)


### JavaScript

* [JavaScript](http://ilkaddimlar.com/ders/javascript)


### Linux

* [Linux](http://ilkaddimlar.com/ders/linux)


### PHP

* [PHP](http://ilkaddimlar.com/ders/php)
