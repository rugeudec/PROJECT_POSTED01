### Index

* [IoT (internet of things)](#iot-internet-of-things)
* [Java](#java)
* [Python](#python)


### IoT (internet of things)

* [Introduction to Wireless Sensor Networks-แนะนำเครือข่ายเซนเซอร์ไร้สาย](https://www.nectec.or.th/news/news-public-document/introwsn.html) - ผศ.ดร.วรรณรัช สันติอมรทัต และ ผศ.ดร.สกุณา เจริญปัญญาศักดิ์


### Java

* [โครงสร้างข้อมูลฉบับวาจาจาวา](https://www.cp.eng.chula.ac.th/books/ds-vjjv/) - สมชาย ประสิทธิ์จูตระกูล
* [Java Programming Concept](http://it.e-tech.ac.th/poohdevil/JavaConcepts/) - Rungrote Phonkam


### Python

* [Python ๑๐๑](https://www.cp.eng.chula.ac.th/books/python101/) - กิตติภณ พละการ, กิตติภพ พละการ, สมชาย ประสิทธิ์จูตระกูล , สุกรี สินธุภิญโญ

